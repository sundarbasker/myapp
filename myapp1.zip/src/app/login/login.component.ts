import { Component, OnInit  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormGroup, FormControl, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit  {
  registerForm:any = FormGroup;
  submitted = false;
  
  constructor( private fb: FormBuilder, private router:Router ) { }



  ngOnInit() {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', Validators.compose([Validators.required])]
    }
    );
 }

 get f() { return this.registerForm.controls; }
//  get registerFormControl() {
//   return this.registerForm.controls;
// }

onSubmit() {
  
  this.submitted = true;
  if (this.registerForm.valid) {
   // return
    alert('Form Submitted succesfully!!!\n Check the values in browser console.');
    console.table(this.registerForm.value);
    this.router.navigate(['/employee'])
  }
}
}
