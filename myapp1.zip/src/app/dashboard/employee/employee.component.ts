import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from 'src/app/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']

})
export class EmployeeComponent {
  constructor(private data:EmployeeService, private router: Router) { }
  employeeslist: any;
  
  friends: any = [];

  ngOnInit(): void {

    this.friends = [
{name: "Sundar", place:"Bangalore"},
{name: "Sujith", place:"Coimbatore"},
{name: "Manoj", place:"Cochin"},
{name: "Rahul", place:"Hyderabad"}

    ]

    

    this.data.getList().subscribe(data=>{
      this.employeeslist = data;
      console.log('List data',this.data)
    })
  }

}
