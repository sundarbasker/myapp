import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { EmployeeComponent } from './dashboard/employee/employee.component';
import { ProductComponent } from './dashboard/product/product.component';
import { Login1Component } from './login1/login1.component';


const routes: Routes = [
  {
    path:'', component: LoginComponent
  },
  // {
  //   path:'', component: LoginComponent
  // },
  {
    path: 'employee', component: EmployeeComponent
  },
  {
    path: 'product', component: ProductComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
