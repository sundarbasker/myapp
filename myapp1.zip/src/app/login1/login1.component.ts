import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login1',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './login1.component.html',
  styleUrls: ['./login1.component.scss']
})
export class Login1Component {
buildHash = new Date().toISOString();
}
